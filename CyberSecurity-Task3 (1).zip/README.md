# Cyber Security Internship - Task 3

## 📌 Task: Perform a Basic Vulnerability Scan on Your PC

### Objective:
Use free tools (OpenVAS Community Edition or Nessus Essentials) to identify common vulnerabilities on your computer.

### Deliverables:
- Vulnerability scan report (PDF included in this repo).
- Screenshots or additional notes (if available).

### Tools:
- OpenVAS (Community Edition)
- Nessus Essentials

### Key Concepts:
- Vulnerability scanning
- Risk assessment
- CVSS
- Remediation
- Security tools

### Files in this Repository:
- `task 3.pdf` → Task instructions and guidelines
- `README.md` → This file

---

✅ Upload this repository link as your submission.
